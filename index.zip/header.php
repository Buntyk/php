 <body class="body">
              <div class="logo" align="left">
              <img src="css/images/logo.png" alt="logo" width="200" height="100" /><i class="fa fa-search">&nbsp;</i><input type="text" placeholder="Search.."><i class="fa fa-facebook-square">&nbsp;</i><i class="fa fa-google-plus-square"></i>&nbsp;<i class="fa fa-youtube-square"></i>

                  </div>                       
                  <div class="small-icons">
                      <li align="right">
                      <i class="fa fa-envelope" > &nbsp;&nbsp;XYZ@GMAIL.COM</i> &nbsp;&nbsp;&nbsp;&nbsp;
                      <i class="fa fa-phone" >&nbsp;&nbsp;0181-2225478</i>      

                      </li>
                  </div>
              