<?php 

$names= array("firstname"=>'edwin', "secondname"=>'diaz');

// echo $names['firstname'];

print_r($names);

foreach ($names as $name) {
	# code...
	print_r($name) ;
}


?>