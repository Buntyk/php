<footer align="center">
        <table bgcolor="#1384A8" align="center" cellspacing="15" width="1300" class="topnav1">
            
            <tr align="center">
               <td><h3><u>Newsletter</u></h3>
                <p>Subscription to aware our latest destinations</p>
                <div class="input-group">
                          <form action="#" method="post">
                                <input name="email" type="email" placeholder="Enter your email" class="form-control" autorequired>
                              <button type="submit" name="submit" class="btn email">Submit</button>
                            </form></td>


              <td>  <h3><u>Tour and Travel</u></h3>
                <p>Reach us 
                       <p><i class="fa fa-phone"></i> 010-020-0340</p>
                       <p><i class="fa fa-envelope-o"></i> info@company.com</p>
                      <p><i class="fa fa-globe"></i> www.company.com</p></td>


              <td><h3><u>Newsletter</u></h3>
                <p>Subscription to aware our latest destinations</p>
                <div class="input-group">
                          <form action="#" method="post">
                                <input name="email" type="email" placeholder="Enter your email" class="form-control" autorequired>
                              <button type="submit" name="submit" class="btn email">Submit</button>
                            </form></td>


              <td><h3><u>Newsletter</u></h3>
                <p>Subscription to aware our latest destinations</p>
                <div class="input-group">
                          <form action="#" method="post">
                                <input name="email" type="email" placeholder="Enter your email" class="form-control" autorequired>
                              <button type="submit" name="submit" class="btn email">Submit</button>
                            </form></td>
            </tr>

        </table>
</footer>

<p align="center"><b>Copyright © 2020 Tour and Travel</b></p>
