 
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<center>	
	<title>
		
	</title>
				<div class="navbar">
							<ul>

							<li class="active"><a href=""><i class="fa fa-home"></i>HOME</a></li>
							<li><a href=""><i class="fa fa-user"></i>ABOUT US</a></li>
							<li><a href=""><i class="fa fa-cutlery"></i>DESTINATION</a></li>
							<li><a href=""><i class="fa fa-cutlery"></i>PACKAGES</a></li>
							<li><a href=""><i class="fa fa-phone"></i>GALLERY

										<div class="sub-menu">
											<ul>
												<li><a href="">MEMORIES</a></li>
												<li><a href="">BEAUTIFUL-MOMENTS</a></li>
												<li><a href="">COMMENTS</a></li>
											</ul>
										</div></li>	
							<li><a href=""><i class="fa fa-phone"></i>CONTACT US</a></li>
													
							</ul>
								
								
							
							
							

	
					</DIV>
	
<div class="slideshow-container">




<div class="mySlides fade">
	
  <img src="images/tour.jpg" style="width: 100%">


  <div class="text"></div>
 
</div>

<!-- Main Menu  -->

<div class="navbar">
							<ul>

							<li class="active"><a href=""><i class="fa fa-home"></i>HOME</a></li>
							<li><a href=""><i class="fa fa-user"></i>	ABOUT US</a></li>
							<li><a href=""><i class="fa fa-cutlery"></i>VEG CORNER</a></li>
							<li><a href=""><i class="fa fa-cutlery"></i>NON-VEG CORNER</a></li>
							<li><a href=""><i class="fa fa-phone"></i>CONTACT US</a></li>
														<li><a href="all_in_one_login.php">SIGN IN</a>
							<li><a href="">REGISTRATION</a>
													
							</li></li></a></li></ul>
								
								
							
							
							

	
					</DIV> <br><br><br>	


</div></div>

<body >



<table border="0" width="70%" align="right">
		<tr align="left">
			<th colspan="2" align="left"><font size="20%"> Today's Special Offer</font><hr></hr></th>
		</tr>
</table><br><br><br><br>

				<!-- Products table including pictues of products, discount on it, price of that product and add to cart option  -->


		<table border="0"  style="float: left;" width="20%" cellspacing="70">

						<tr>
							<td align="center"> <h2>Laptops</h2><a href=""><input type="image" src="images/8.jpg" name="product_image" readonly="" width="270"  height="310"></a></td>	

						<td align="center"><h2>Mobiles</h2><a href=""><input type="image" src="images/mobiles.jpg" name="product_image" width="270" height="310"></a></td>
					<td align="center"><h2>Beverages</h2><input type="image" src="images/2.png" name="product_image"  width="270"  height="310"></td></tr>
						
						
		</table>

		<table border="0" width="70%" align="right">
		<tr align="left">
			<th colspan="2" align="left"><font size="20%"> Hot Offers</font><hr></hr></th>
		</tr>
</table><br><br><br><br>
		<table border="0"  style="float: left;" width="50%" cellspacing="180">

						<tr>
							<td align="center"><input type="image" src="images/8.jpg" name="product_image" readonly="" width="200"></td>	

						<td  align="center"><input type="image" src="images/8.jpg" name="product_image" readonly="" width="200"></td>
					<td align="center"><input type="image" src="images/8.jpg" name="product_image" readonly="" width="200"></td></tr>
						
						
		</table>






		<br><br><br><br><br><br>
	</form>
</body>


<!-- Footer start from here  -->

<body>
<div class="footer">
<table border="0" height="200" width="1340" bgcolor="#333">	
	




	
	<tr>
	
		<th align=" center">
		<div class="footer">
		<div class="container">
			<div class="col-md-1 w3_footer_grid">
				<ul>
					<li><h3>INFORMATION</h3></li></ul>
					
				
				<ul class="w3_footer_grid_list">
					<li><a href="events.php">Events</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="best-deals.php">Best Deals</a></li>
					<li><a href="services.php">Services</a></li>
					
				</ul>
			</div></th><th>
			<div class="col-md-2 w3_footer_grid">
				<ul><h3>POLICY INFO</h3></ul>
					
				<ul class="w3_footer_grid_list">
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="privacy.php">privacy policy</a></li>
					<li><a href="terms.php">terms of use</a></li>
				</ul>
			</div></th><th>
			<div class="col-md-3 w3_footer_grid">
			
					<ul><h3>WHAT IN STORE</h3>	</ul>
				<ul class="w3_footer_grid_list">
					<li><a href="pet-food.php">Pet Food</a></li>
					<li><a href="frozen.php">Frozen Snacks</a></li>
					<li><a href="kitchen.php">Kitchen</a></li>
					<li><a href="branded-food.php">Branded Foods</a></li>
					
				</ul>
			</div>
		</th>

	</tr>
</table></center></div></div></th></tr></table></body>
</html>
